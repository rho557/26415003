#!/bin/bash

sort -t- -k3 -k2 -k1 namelist0 >namelist1
